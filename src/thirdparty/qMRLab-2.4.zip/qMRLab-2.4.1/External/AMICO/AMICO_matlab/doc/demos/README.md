# Tutorials/demos

This folder contains a series of tutorials/demos to show how to use the AMICO framework.