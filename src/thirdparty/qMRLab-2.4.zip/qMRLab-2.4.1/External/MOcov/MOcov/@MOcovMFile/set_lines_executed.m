function obj=set_lines_executed(obj, lines)
    obj.executed(lines)=true;
