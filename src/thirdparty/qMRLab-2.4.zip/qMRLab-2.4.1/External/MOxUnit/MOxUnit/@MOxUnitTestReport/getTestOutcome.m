function test_outcome=getTestOutcome(obj,i)
    test_outcome=obj.test_outcomes{i};
