function disp(obj)
% Display string representation of MoxUnitTestNode instance
%
% disp(obj)
%
% Input:
%   obj             empty MOxUnitTestNode instance.
%
% NNO 2015

    disp(str(obj));
