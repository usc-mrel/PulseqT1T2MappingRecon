function disp(obj)
% display MoxUnitTestSuite object
%
% disp(obj)
%
% Inputs:
%   obj             MoxUnitTestSuite object
%
% NNO 2015

    disp(str(obj));